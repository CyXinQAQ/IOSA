function [ A, b, xstar ] = mat1( n )

% generate the matrix A
A = 8*eye(n,n);
for i = 1:n
    for j = 1:n
        if abs(j-i) == 1
            A(i,j) = -1;
        end
    end
end

% generate the exact solution xstar
xstar = zeros(n,1);
for i = 1:n
    xstar(i) = (-1)^i;
end

% generate the right-hand-side vector b
b = A*xstar - abs(xstar);

% sparsing
A = sparse(A);
xstar = sparse(xstar);
b = sparse(b);