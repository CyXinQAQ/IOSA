%Consider the following two-point boundary value problems
%$$
%\left\{\begin{array}{l}
%\frac{d^2 u}{d t^2}-|u|=\left(1-t^2\right), 0 \leq t \leq 1. \\
%u(0)=-1, u(1)=0
%\end{array}\right.
%$$

clc,clear
np=1;
n=10;
h=1/(n+1);
u0=-1;ub=0;
t=h:h:n*h;
b=1-t.^2;b=b';
b(1)=b(1)+1/(h^2);

sp=0;
% sp: sparsity indicator
%     if sp  = 0: full storage organization is used
%     if sp ~= 0: sparse storage organization is used
% n = 10000
for n=n
    fprintf('问题的维度 %d \n',n)
    gamma = 1.85;
    tol   = 1e-6;
    cs = 1; % solve each problem five times
    MaxIt=20000;
    N=5;%算法的个数
    timecount=zeros(1,N);
    itcount=zeros(1,N);
    inneritcount=zeros(1,N);
    rescount=zeros(1,N);
    for i = 1:np
        main_diag = -2*ones(n, 1); 
        upper_diag = 1*ones(n-1, 1);  
        lower_diag = 1*ones(n-1, 1); 
        A = diag(main_diag) + diag(upper_diag, 1) + diag(lower_diag, -1);
        A=1/(h^2)*A;
        bvector=b;
        xini=zeros(n,1);
        for j = 1:cs % run each method cs times
            %% Inexact DRs
            out = InexactDRs( A, bvector, xini, n, gamma, tol);
            timecount(1)=timecount(1)+out.time;
            itcount(1)=itcount(1)+out.it;
            inneritcount(1)=inneritcount(1)+out.inner;
            rescount(1)=rescount(1)+out.F(end);
            %% IOSA-constant-beta;
            beta=1;
            opt.gamma=1.85;
            opt.tol=tol;
            opt.n=n;
            opt.maxit=MaxIt;
            opt.x=xini;
            opt.beta=beta;
            opt.betastyle='constant';
            opt.alpha=0.1;
            outc=IOSA(A,bvector,opt);
            timecount(2)=timecount(2)+outc.time;
            itcount(2)=itcount(2)+outc.it;
            inneritcount(2)=inneritcount(2)+outc.innerit;
            rescount(2)=rescount(2)+outc.F(end);
            %% IOSA-adaptive-beta;
            beta=1;
            tau=0.5;
            alpha=0.1;
            opt.gamma=1.85;
            opt.tol=tol;
            opt.n=n;
            opt.maxit=MaxIt;
            opt.x=xini;
            opt.beta=beta;
            opt.betastyle='Adaptive';
            opt.alpha=alpha;
            opt.tau=tau;
            outA=IOSA(A,bvector,opt);
            timecount(3)=timecount(3)+outA.time;
            itcount(3)=itcount(3)+outA.it;
            inneritcount(3)=inneritcount(3)+outA.innerit;
            rescount(3)=rescount(3)+outA.F(end);
            %% IOSA1-constant-beta;
            beta=1;
            opt.gamma=1.85;
            opt.tol=tol;
            opt.n=n;
            opt.maxit=MaxIt;
            opt.x=xini;
            opt.beta=beta;
            opt.betastyle='constant';
            opt.alpha=0.1;
            outc1=IOSA1(A,bvector,opt);
            timecount(4)=timecount(4)+outc1.time;
            itcount(4)=itcount(4)+outc1.it;
            inneritcount(4)=inneritcount(4)+outc1.innerit;
            rescount(4)=rescount(4)+outc1.F(end);
            %% IOSA1-adaptive-beta;
            beta=1;
            tau=0.5;
            alpha=0.1;
            opt.gamma=1.85;
            opt.tol=tol;
            opt.n=n;
            opt.maxit=MaxIt;
            opt.x=xini;
            opt.beta=beta;
            opt.betastyle='Adaptive';
            opt.alpha=alpha;
            opt.tau=tau;
            outA1=IOSA1(A,bvector,opt);
            timecount(5)=timecount(5)+outA1.time;
            itcount(5)=itcount(5)+outA1.it;
            inneritcount(5)=inneritcount(5)+outA1.innerit;
            rescount(5)=rescount(5)+outA1.F(end);
        end
    end
    %% 输出
    disp('-------------------------------------------------------------------')
    disp('------------------—--------   输出结果   ---------------------------')
    disp('-------------------------------------------------------------------')
    for i=1:N
        fprintf(' %3d    %4d         %4d      %6.2e \n',timecount(i),itcount(i),inneritcount(i),rescount(i));
    end
end

outx=[out.x outc.x outA.x outc1.x outA1.x];




