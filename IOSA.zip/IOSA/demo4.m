
clc,clear


np=10;
sp=0;
% sp: sparsity indicator
%     if sp  = 0: full storage organization is used
%     if sp ~= 0: sparse storage organization is used
% n = 10000
n=500;
%vdensity = 0.003 + (0.004 - 0.003).*rand(np,1);
%  n=dim(k);
%  vcond=conddim(p)+(0.2*conddim(p)).*rand(np,1);
%  fprintf('The number of test problems  %d %d\n',n,conddim(p));
% vcond = 10 + (20 - 10).*rand(np,1);
% vdensity = 0.1 + (0.12 - 0.1).*rand(np,1);



gamma = 1.85;
tol   = 1e-6;

cs = 1; % solve each problem five times

VcondA = zeros(np,1);
Vdensity = zeros(np,1);
MaxIt=20000;
N=5;%算法的个数
timecount=zeros(1,N);
itcount=zeros(1,N);
inneritcount=zeros(1,N);
rescount=zeros(1,N);

for i = 1:np
    
     fprintf('The number of test problems is: %d \n',i)
     
     
    A=0.5*ones(n,n);
    for j=1:n
        A(j,j)=4*n;
    end
    for j=1:n-1
        A(j,j+1)=n;
        A(j+1,j)=n;
    end
     
     
     % generate the exact solution xstar
% xstar = zeros(n,1);
% for i = 1:n
%     xstar(i) = (-1)^i;
% end
xstar=ones(n,1);

% generate the right-hand-side vector b
bvector = A*xstar - abs(xstar);


norm(A'*A-eye(n))

% sparsing
% A = sparse(A);
% xstar = sparse(xstar);
% bvector = sparse(bvector);
     xini=zeros(n,1);
     for j=1:n
         xini(j)=0.001*j;
     end
    
    
    for j = 1:cs % run each method cs times
        
        %            [~,~,~,timenew,flagn] = Newton(A,bvector,n,sp,xini,tol);
        %
        %            [~,~,~,timeienew,flagin] = InexactNewton(A,bvector,n,sp,xini,theta,tol);
        %
        %            [ ~, ~, ~, timeedrs, flagd]  = DRs( A, bvector, xini, gamma, tol);
        %
        %            [~,~, ~, timeesor, flags ] = SORl( A, bvector, xini, xini, normAinv, tol);
        %
        % [F1,~,it1,timeiedrs,flagid] = InexactDRs1( A, bvector, xini, n, gamma, tol);
        out = InexactDRs( A, bvector, xini, n, gamma, tol)
        timecount(1)=timecount(1)+out.time;
        itcount(1)=itcount(1)+out.it;
        inneritcount(1)=inneritcount(1)+out.inner;
        rescount(1)=rescount(1)+out.F(end);
        %[F2,~,it2,timeiedrs,~] = InexactDRs2( A, bvector, xini, n, gamma, tol);
        
        %% IOSA-constant-beta;
        beta=1;
        opt.gamma=1.85;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=MaxIt;
        opt.x=xini;
        opt.beta=beta;
        opt.betastyle='constant';
        opt.alpha=0.5;
        outc=IOSA(A,bvector,opt)
        timecount(2)=timecount(2)+outc.time;
        itcount(2)=itcount(2)+outc.it;
        inneritcount(2)=inneritcount(2)+outc.innerit;
        rescount(2)=rescount(2)+outc.F(end);


%         %% IOSA-adaptive-beta;
%         beta=0.8;
%         tau=0.5;
%         alpha=0.1;
%         opt.gamma=1.85;
%         opt.tol=tol;
%         opt.n=n;
%         opt.maxit=5000;
%         opt.x=xini;
%         opt.beta=beta;
%         opt.betastyle='Adaptive';
%         opt.alpha=alpha;
%         opt.tau=tau;
%         outA=IOSA(A,bvector,opt)
%         timecount(5)=timecount(5)+outA.time;
%         itcount(5)=itcount(5)+outA.it;
%         inneritcount(5)=inneritcount(5)+outA.innerit;
%         rescount(5)=rescount(5)+outA.F(end);
%         
%         
%         %% IOSA-constant-beta;
%         beta=1;
%         opt.gamma=1.85;
%         opt.tol=tol;
%         opt.n=n;
%         opt.maxit=5000;
%         opt.x=xini;
%         opt.beta=beta;
%         opt.betastyle='constant';
%         opt.alpha=0.5;
%         outc1=IOSA1(A,bvector,opt)
%         timecount(4)=timecount(4)+outc1.time;
%         itcount(4)=itcount(4)+outc1.it;
%         inneritcount(4)=inneritcount(4)+outc1.innerit;
%         rescount(4)=rescount(4)+outc1.F(end);
        %% IOSA-adaptive-beta;
        beta=1;
        tau=0.5;
        alpha=0.5;% 0.1
        opt.gamma=1.85;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=MaxIt;
        opt.x=xini;
        opt.beta=beta;
        opt.betastyle='Adaptive';
        opt.alpha=alpha;
        opt.tau=tau;
        outA1=IOSA1(A,bvector,opt)
        timecount(3)=timecount(3)+outA1.time;
        itcount(3)=itcount(3)+outA1.it;
        inneritcount(3)=inneritcount(3)+outA1.innerit;
        rescount(3)=rescount(3)+outA1.F(end);
        
        
    end
    
    
end



%% 输出
disp('-------------------------------------------------------------------')
disp('------------------—--------   输出结果   ---------------------------')
disp('-------------------------------------------------------------------')
for i=1:N
    fprintf(' %3d    %4d         %4d      %6.2e \n',timecount(i),itcount(i),inneritcount(i),rescount(i));
end
%plot


plot(1:out.it,log(out.F),'b-','LineWidth',1.5);
hold on
%plot(1:it1-1,log(F1(1:it1-1)),'r:','LineWidth',1.5)
%plot(1:it2-1,log(F2(1:it2-1)),'k--','LineWidth',2)
plot(1:outc.it,log(outc.F),'r--','LineWidth',1.5)
grid on
plot(1:outA1.it,log(outA1.F),'k:','LineWidth',2)
%legend('IMA-IDR','非精确1','非精确2','IOSA')
legend('InexactDR','Algorithm 1','Algorithm 2')
xlabel('Iteration', 'fontsize', 14); ylabel('||log(e(x^k,1))||', 'fontsize', 14);








