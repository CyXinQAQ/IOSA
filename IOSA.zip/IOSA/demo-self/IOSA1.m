function out=IOSA1(H,b,opt)
gamma=opt.gamma;
tol=opt.tol;
n=opt.n;
maxit=opt.maxit;
x_0=opt.x;
betastyle=opt.betastyle;
beta=opt.beta;

[V,D]=eig(H);%Do SVD decomposition for H, H=VDV^T; H^{-1}=V*D^{-1}*V^T;
d = diag(D);

H1 = eye(n)+beta*H;
[l1,l2] = lu(H1);
%invH=inv(eye(n)+beta*H)
invH = l2\(l1\eye(n));

% sub-problem
x_old=x_0;
e=min(x_old,beta*(H*x_old+b));
x_new=x_old+gamma*invH*e;
x_old=x_new;

it=1;

t0=tic;

%% beta 的选取方式
switch betastyle
    case 'constant'
        while it <= maxit
            beta = opt.beta;
            x_old=x_new;
            e=min(x_old,beta*(H*x_old+b));
            F=norm(e);
            out.it=it;
            if F <= tol
                out.F=F;
                out.it=it;
                break
            end
            x_new=x_old-gamma*invH*e;
            it = it + 1;
        end
    case 'Adaptive'
        alpha = opt.alpha;
        tau = opt.tau;
        while it <= maxit
            x_res=x_new-x_old;
            W=beta*norm(H*x_res)/norm(x_res);
            if W<(1/(1+alpha))
                beta=(1+tau)*beta;
            elseif W>(1+alpha)
                beta=beta/(1+tau);
            end
            x_old=x_new;
            e=min(x_old,beta*(H*x_old+b));
            F=norm(e);
            out.it=it;
            if F <= tol
                out.F=F;
                out.it=it;
                break
            end
            d1 = 1./(1 + beta.*d);
            invHe = V*(d1.*(V'*e));
            x_new=x_old-gamma*invHe;
            it = it + 1;
        end
end


out.time=toc(t0);
out.x=x_old;

end
