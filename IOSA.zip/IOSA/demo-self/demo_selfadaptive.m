% check the self-adaptive stragtegy
n=1000;
A=-2*rand(n)+ones(n);  %-1到1之间的随机矩阵
H=A'*A;
L=eigs(H,1);
b= 2*rand(n,1)-1;%-1到1之间的随机向量
%% 输出
disp('-------------------------------------------------------------------')
disp('------------------—--------   输出结果   ---------------------------')
disp('-------------------------------------------------------------------')
disp('    Time        outIter.           Res')

%% parameters setting-constant
opt.gamma=1.8; opt.betastyle='constant';
opt.tol=1e-6; opt.n=n; opt.maxit=1000; opt.x=rand(n,1)/100;
temp=0.2:0.2:2;
for beta = 1/L.*temp
    opt.beta=beta;
    out=IOSA1(H,b,opt);
    fprintf(' %3d    %4d         %6.2e \n',out.time,out.it,out.F);
end
%% parameters setting-adaptive
opt.beta = 1.2/L;   opt.gamma=1.8; opt.betastyle='Adaptive';
opt.tol=1e-6; opt.n=n; opt.maxit=1000;  opt.alpha=0.1;
opt.tau=0.5;
out=IOSA1(H,b,opt);
disp('    Time        outIter.           Res')
fprintf(' %3d    %4d         %6.2e \n',out.time,out.it,out.F);
