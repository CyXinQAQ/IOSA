function [x_old, flag, k ,error] = olsqr2(A,b,n,x_old,B,c,option,varargin)
eta=option.eta;
beta1=option.beta;
tol=option.tol;
%BTB=B'*B;
%C=BTB-eye(n);

%[atype1,afun1,afcnstr1] = iterchk(B);
%R=@(x) x'*(iterapp('mtimes',afun1,atype1,afcnstr1,x,varargin{:}));
%B=sparse(B);

maxit = 2*n;

[atype,afun,afcnstr] = iterchk(A);

u = b - iterapp('mtimes',afun,atype,afcnstr,x_old,varargin{:});  % r = b - A*x
beta = norm(u);
u = u/beta;

v = iterapp('mtimes',afun,atype,afcnstr,u,varargin{:},'transp');
alpha = norm(v);
v = v/alpha;

w = v;

phibar = beta;
rhohat = alpha;

k = 1;
flag = -1; % an error occurred during the execution
while k<= maxit
    
    u = iterapp('mtimes',afun,atype,afcnstr,v,varargin{:}) - alpha*u;
    beta = norm(u);
    u = u/beta;
    
    v = iterapp('mtimes',afun,atype,afcnstr,u,varargin{:},'transp') - beta*v;
    alpha = norm(v);
    v = v/alpha;
    
    rho = sqrt( rhohat^2 + beta^2 );
    c = rhohat/rho;
    s = beta/rho;
    theta = s*alpha;
    rhohat = -c*alpha;
    phi = c*phibar;
    phibar = s*phibar;
    
    res=(phi*w)/rho;
    x_old = x_old + res;
    w = v - (theta*w)/rho;
    
    %tol=eta;
    
    %tol=eta*beta1*R(x_old-xk);
    
    
%     res1=B*x_old-abs(x_old)-c;
%     tol=0.0001^2*norm(option.res-res1)^2;
    %tol=max(tol,1e-8);
    error=tol;
    if phibar <= tol % || b - Ax_k || <= tol
        flag = 0; % success    
        break
    end
    
    k = k + 1;
end

end

