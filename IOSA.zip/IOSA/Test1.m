%function [ rm ] = Test1( n, np, sp)
clc,clear
n=10;
np=1;
sp=1;
% sp: sparsity indicator
%     if sp  = 0: full storage organization is used
%     if sp ~= 0: sparse storage organization is used

% n = 10000
vcond = 100 + (120 - 100).*rand(np,1);
vdensity = 0.003 + (0.004 - 0.003).*rand(np,1);


% % vcond = 10 + (20 - 10).*rand(np,1);
% % vdensity = 0.1 + (0.12 - 0.1).*rand(np,1);
%
% vcond = 30 + (50 - 30).*rand(np,1);
% vdensity = 0.4 + (0.42 - 0.4).*rand(np,1);


gamma = 1.8;
tol   = 1e-6;

cs = 1; % solve each problem five times

VcondA = zeros(np,1);
Vdensity = zeros(np,1);
vmintime = zeros(np,1);
vrm = zeros(np,1);
vtimen = zeros(np,1);
vtimein = zeros(np,1);
vtimed = zeros(np,1);
vtimeid = zeros(np,1);
vtimes = zeros(np,1);
vflagn = zeros(np,1);
vflagin = zeros(np,1);
vflagd = zeros(np,1);
vflagid = zeros(np,1);
vflags = zeros(np,1);

for i = 1:np
    
    fprintf('The number of test problems is: %d \n',i)
    
    [A,bvector,~,xini,theta,~,normAinv,~,condA,density] = data( n, vdensity(i), vcond(i) );
    
    VcondA(i) = condA
    Vdensity(i) = density;
    
    
    
    
    timeid = zeros(cs,1);
    
    
    for j = 1:cs % run each method cs times
        
        
        
        [F1,~,it1,timeiedrs,flagid] = InexactDRs1( A, bvector, xini, n, gamma, tol);
        timeid(j) = timeiedrs;
        [F,~,it,timeiedrs,~] = InexactDRs( A, bvector, xini, n, gamma, tol);
        [F2,~,it2,timeiedrs,~] = InexactDRs2( A, bvector, xini, n, gamma, tol);
        
        %% IOSA
        opt.gamma=1.5;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=500;
        opt.x=xini;
        out=IOSA(A,bvector,opt)
        
    end
    
    %%%%%%%%% average of running time %%%%%%%%%%%%%%%
    timeid = mean(timeid(:));
    
    
    
end

rmo = max(vrm);
rm = ceil(rmo) + 10;


rpsid = zeros(np,1);

for i = 1:np
    if vflagn(i) == 0
        rpsn(i) = vtimen(i)/vmintime(i);
    else
        rpsn(i) = rm;
    end
    
    if vflagin(i) == 0
        rpsin(i) = vtimein(i)/vmintime(i);
    else
        rpsin(i) = rm;
    end
    
    if vflagd(i) == 0
        rpsd(i) = vtimed(i)/vmintime(i);
    else
        rpsd(i) = rm;
    end
    
    if vflagid(i) == 0
        rpsid(i) = vtimeid(i)/vmintime(i);
    else
        rpsid(i) = rm;
    end
    
    if vflags(i) == 0
        rpss(i) = vtimes(i)/vmintime(i);
    else
        rpss(i) = rm;
    end
end



%plot

plot(1:it,log(F),'b-','LineWidth',1.5);
hold on
plot(1:it1,log(F1),'r:','LineWidth',1.5)
plot(1:it2-1,log(F2(1:it2-1)),'k--','LineWidth',2)
plot(1:out.it,log(out.F),'r--','LineWidth',2)
grid on
legend('IMA-IDR','非精确1','非精确2','IOSA')
xlabel('Iteration', 'fontsize', 14); ylabel('||log(e(x^k,1))||', 'fontsize', 14);








