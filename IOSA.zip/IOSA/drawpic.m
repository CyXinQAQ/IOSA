
clc,clear

np=1;
sp=0;

n=2500;
vcond = 1000 + (1200 - 1000).*rand(np,1);

vdensity = 0.95 + (0.92 - 0.9).*rand(np,1);

%vdensity = 0.8 + (0.82 - 0.8).*rand(np,1);

gamma = 1.85;
tol   = 1e-6;

cs = 1; % solve each problem five times

VcondA = zeros(np,1);
Vdensity = zeros(np,1);

N=5;%算法的个数
timecount=zeros(1,N);
itcount=zeros(1,N);
inneritcount=zeros(1,N);
rescount=zeros(1,N);

for i = 1:np
    
     fprintf('The number of test problems is: %d \n',i)
    
    [A,bvector,~,xini,theta,~,normAinv,~,condA,density] = data( n, vdensity(i), vcond(i) );
    VcondA(i) = condA;
    Vdensity(i) = density;
    
    
 
        % [F1,~,it1,timeiedrs,flagid] = InexactDRs1( A, bvector, xini, n, gamma, tol);
        out = InexactDRs( A, bvector, xini, n, gamma, tol);

       
        %% IOSA-constant-beta;
        beta=1;
        opt.gamma=1.85;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=5000;
        opt.x=xini;
        opt.beta=beta;
        opt.betastyle='constant';
        opt.alpha=0.1;
        outc=IOSA(A,bvector,opt);
        
        %% 
        beta=1;
        tau=0.5;
        alpha=0.1;
        opt.gamma=1.85;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=5000;
        opt.x=xini;
        opt.beta=beta;
        opt.betastyle='Adaptive';
        opt.alpha=alpha;
        opt.tau=tau;
        outA=IOSA(A,bvector,opt);
        %% 
        beta=1;
        tau=0.5;
        alpha=0.1;
        opt.gamma=1.85;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=5000;
        opt.x=xini;
        opt.beta=beta;
        opt.betastyle='constant';
        opt.alpha=alpha;
        opt.tau=tau;
        outc1=IOSA1(A,bvector,opt);
        
        %% IOSA-adaptive-beta;
        beta=1;
        tau=0.5;
        alpha=0.1;
        opt.gamma=1.85;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=5000;
        opt.x=xini;
        opt.beta=beta;
        opt.betastyle='Adaptive';
        opt.alpha=alpha;
        opt.tau=tau;
        outA1=IOSA1(A,bvector,opt);
        
        
    
    
end





plot(out.Trecord,log(out.F),'b-x','LineWidth',1.5);
hold on
plot(outc.Trecord,log(outc.F),'k:+','LineWidth',1.5)
hold on
plot(outA.Trecord,log(outc.F),'r-->','LineWidth',1.5)
hold on
plot(outc1.Trecord,log(outc1.F),'c:*','LineWidth',1.5)
hold on 
plot(outA1.Trecord,log(outA1.F),'m:s','LineWidth',1.5)
grid on
%legend('IMA-IDR','非精确1','非精确2','IOSA')
legend('Method in [16]','Algorithm 3.1-C','Algorithm 3.1-A','Algorithm 3.2-C','Algorithm 3.2-A')
xlabel('CPU time(seconds)', 'fontsize', 14); ylabel('log(||e(x^k,1)||)', 'fontsize', 14);








