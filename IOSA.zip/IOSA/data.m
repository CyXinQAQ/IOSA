function [A,bvector,xsol,xini,theta,normA,normAinv,minsingval,condA,density] = data(n,density,cond)

% This function generates an AVE problem as described in 

% J.Y. Bello Cruz, O. P. Ferreira, L. F. Prudente. On the global convergence
% of the inexact semi-smooth Newton method for absolute value equation 

%--------------------- Input arguments ------------------------------------

% n: dimension of the problem

% density: approximate density of matrix A

% cond: order of condition number of A
%       cond <= cond(A) <= 10 * cond

%--------------------- Output arguments -----------------------------------

% A,bvector: data of the AVE problem Ax - |x| = bvector; 
%            A is nxn real matriz and bvector is nx1 real vector 

% xsol: solution of AVE

% xini: initial point

% theta: tolerance factor for Inexact Newton subproblems

% normA: 2-norm of A

% normAinv: 2-norm of inv(A)

% minsingval: minimal singular value of A

% condA: condition number of A

% density: density of A

% Defining singular values of A:

%--------------------------------------------------------------------------

%rng(456); %   RNG(SD) seeds the random number generator using the non-negative
%             integer SD so that RAND, RANDI, and RANDN produce a predictable
%             sequence of numbers.

condA = 0;

while ( condA < cond  || condA > 10*cond ) % (or) s.t. cond <= cond(A) <= 10 * cond

    ab = rand(4,1);
    a = min(ab);
    b = max(ab); 

    singval = a + (b-a).*rand(n,1);

    condA = max(singval)/min(singval);

end

% Reescaling the singular values of A in order to minsingvalA > 3
singval = 3*singval/(rand*min(singval));

% Computing ||A|| , ||A^(-1)|| and cond(A):
minsingval = min(singval);

normA    = max(singval);
normAinv = 1/minsingval;
condA    = normA * normAinv;

% Computing theta:
% theta = (1-3*normAinv)*(1-normAinv)/(normAinv*(1+normA)*(1+normAinv));
theta = (1 - 3*normAinv)/(normAinv*(3 + normA));
theta = theta * 0.9999;

% Generating matrix A:
A = sprand(n,n,density,singval);

density = nnz(A)/n^2;

% Generating aleatory solution
a = -100;
b =  100;

xsol = a + (b-a)*rand(n,1);

bvector = A*xsol - abs(xsol);

% Generating initial point
xini = a + (b-a)*rand(n,1);