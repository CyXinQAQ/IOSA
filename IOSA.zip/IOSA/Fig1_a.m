
clc,clear
np=1;
sp=0;
n=1000;
vcond = 1000 + (1200 - 1000).*rand(np,1);
vdensity = 0.95 + (0.92 - 0.9).*rand(np,1);
gamma = 1.85;
tol   = 1e-6;
cs = 1; % solve each problem five times
VcondA = zeros(np,1);
Vdensity = zeros(np,1);
N=5;%算法的个数
timecount=zeros(1,N);
itcount=zeros(1,N);
inneritcount=zeros(1,N);
rescount=zeros(1,N);

for i = 1:np
    fprintf('The number of test problems is: %d \n',i)
    [A,bvector,~,xini,theta,~,normAinv,~,condA,density] = data( n, vdensity(i), vcond(i) );
    VcondA(i) = condA;
    Vdensity(i) = density;
    
    
    for j = 1:cs % run each method cs times
        
        %% IOSA-constant-beta;
        beta=1;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=5000;
        opt.x=xini;
        opt.beta=beta;
        opt.betastyle='constant';
        opt.alpha=0.1;
        
        opt.gamma=0.8;
        outc0=IOSA(A,bvector,opt);
        opt.gamma=1;
        outc1=IOSA(A,bvector,opt);
        opt.gamma=1.2;
        outc2=IOSA(A,bvector,opt);
        opt.gamma=1.4;
        outc3=IOSA(A,bvector,opt);
        opt.gamma=1.6;
        outc4=IOSA(A,bvector,opt);
        opt.gamma=1.8;
        outc5=IOSA(A,bvector,opt);
        
        
    end
    
    
end




outA1.Trecord(1)=0;

plot(1:3:outc0.it,log(outc0.F(1:3:outc0.it)),'b-*','LineWidth',1.5);
hold on
plot(1:3:outc1.it,log(outc1.F(1:3:outc1.it)),'k:+','LineWidth',1.5);
hold on
plot(1:3:outc2.it,log(outc2.F(1:3:outc2.it)),'g--x','LineWidth',1.5);
hold on
plot(1:3:outc3.it,log(outc3.F(1:3:outc3.it)),'m-.','LineWidth',1.5);
hold on
plot(1:3:outc4.it,log(outc4.F(1:3:outc4.it)),'b:d','LineWidth',1.5);
hold on
plot(1:3:outc5.it,log(outc5.F(1:3:outc5.it)),'r-->','LineWidth',1.5);

grid on

xlim([0 50])
legend('\gamma=0.8','\gamma=1.0','\gamma=1.2','\gamma=1.4','\gamma=1.6','\gamma=1.8')
xlabel('Iteration', 'fontsize', 14); ylabel('log(||(e(x^k,1))||)', 'fontsize', 14);








