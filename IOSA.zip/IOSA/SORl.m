function [ F, x, it, time, flag ] = SORl( A, b, x, y, normAinv, tol )
% This is Exact SOR-like method for Absolute Value Equations 
% (AVE): Ax - |x| = b

% Reference: C.-R. Chen, D.-M. Yu, D.-R. Han. An inexact Douglas-Rachford splitting 
%            method for solving absolute value equations

%--------------------- Input arguments ------------------------------------

% omega: iteration parameter

% A, b: data of the problem Ax - |x| = b; 
%       A is nxn real matrix and b is nx1 real vector 

% x,y: initial point; nx1 real vector 

% tol: accuracy for solution of AVE
%      The method stops at x if || Ax - |x| - b || <= tol


%--------------------- Output arguments -----------------------------------

% x: final iterate

% F: norm of AVE at the final iterate x; 
%    F = || Ax - |x| - b ||

% it: number of iterations of Exact Douglas-Rachford splitting method 

% time: Total CPU time in seconds

% flag = -1: an error occurred during the execution
% flag =  0: solution was found
% flag =  1: maximum of iterations reached

% Print initial information
disp('-------------------------------------------------------------------')
disp('------------------   Initial Information   ------------------------')
disp('-------------------------------------------------------------------')
disp('-------------------------------------------------------------------')
disp('--------------  Exact SOR-like iteration method -------------------')
disp('-------------------------------------------------------------------')
disp(' ')
disp(' It   || Ax - |x| - b ||')
disp(' ')

tic;

flag = -1;

[atype,afun,afcnstr] = iterchk(A);

if normAinv <= 0.25
    omega = 1;
else
    [omega,~] = mbisec(normAinv, 0, 1, 1e-10 );
end

omegam = 1 - omega;

dA = decomposition(A,'lu');

it = 0;
maxit = 50;

while it <= maxit  
    Ax = iterapp('mtimes',afun,atype,afcnstr,x);
    F = norm( Ax - abs(x) -b );
    
    % Print information
    
    fprintf(' %3d       %6.2e \n', it, F)
    
    
    
    z = dA\( y + b );
    x = omegam*x + omega*z;
    y = omegam*y + omega*abs(x);
    
    if F <= tol
        break
    end
    
    it = it + 1;
    
    
    
end

if it == ( maxit + 1 )
    
    flag = 1;
    time = toc;
    disp('SOR-like method fails to find the solution')
    disp('Maximum of iterations reached ')
    fprintf('Time = %10.4f \n',time)
    
else
    
    flag = 0;
    time = toc;
    disp(' ')
    disp('Solution is found')
    fprintf('Time = %10.4f \n',time)
    
end

end