clc,clear

np=1;
sp=0;
% sp: sparsity indicator
%     if sp  = 0: full storage organization is used
%     if sp ~= 0: sparse storage organization is used
% n = 10000
for cd=[500 1000 1500 2000]
for n=500.*[1 2 3 4 5]
vcond = cd + (cd*0.2).*rand(np,1);

fprintf('问题的维度 %d, 条件数 %d\n',n,cd)
vdensity = 0.95 + (0.92 - 0.9).*rand(np,1);
gamma = 1.85;
tol   = 1e-6;

cs = 1; % solve each problem cs times

VcondA = zeros(np,1);
Vdensity = zeros(np,1);

N=5;%算法的个数
timecount=zeros(1,N);
itcount=zeros(1,N);
inneritcount=zeros(1,N);
rescount=zeros(1,N);

for i = 1:np
    [A,bvector,~,xini,theta,~,normAinv,~,condA,density] = data( n, vdensity(i), vcond(i) );
    VcondA(i) = condA;
    Vdensity(i) = density;
  
    for j = 1:cs % run each method cs times
        %% InexactDR
        Method_count=1;
        out = InexactDRs( A, bvector, xini, n, gamma, tol);
        timecount(Method_count)=timecount(Method_count)+out.time;
        itcount(Method_count)=itcount(Method_count)+out.it;
        inneritcount(Method_count)=inneritcount(Method_count)+out.inner;
        rescount(Method_count)=rescount(Method_count)+out.F(end);
        %% IOSA-constant-beta;
        Method_count=Method_count+1;
        beta=1; opt.gamma=1.85; opt.tol=tol; opt.n=n; opt.maxit=5000;
        opt.x=xini; opt.beta=beta; opt.betastyle='constant'; opt.alpha=0.1;
        outc=IOSA(A,bvector,opt);
        timecount(Method_count)=timecount(Method_count)+outc.time;
        itcount(Method_count)=itcount(Method_count)+outc.it;
        inneritcount(Method_count)=inneritcount(Method_count)+outc.innerit;
        rescount(Method_count)=rescount(Method_count)+outc.F(end);
        %% IOSA-adaptive-beta;
        Method_count=Method_count+1;
        beta=1; tau=0.5; alpha=0.1; opt.gamma=1.85; opt.tol=tol; opt.n=n;
        opt.maxit=5000; opt.x=xini; opt.beta=beta; opt.betastyle='Adaptive';
        opt.alpha=alpha; opt.tau=tau;
        outA1=IOSA1(A,bvector,opt);
        timecount(Method_count)=timecount(Method_count)+outA1.time;
        itcount(Method_count)=itcount(Method_count)+outA1.it;
        inneritcount(Method_count)=inneritcount(Method_count)+outA1.innerit;
        rescount(Method_count)=rescount(Method_count)+outA1.F(end);  
        %% IOSA1-constant-beta;
        Method_count=Method_count+1;
        beta=1; opt.gamma=1.85; opt.tol=tol; opt.n=n; opt.maxit=5000;
        opt.x=xini; opt.beta=beta; opt.betastyle='constant'; opt.alpha=0.1;
        outc1=IOSA1(A,bvector,opt);
        timecount(Method_count)=timecount(Method_count)+outc1.time;
        itcount(Method_count)=itcount(Method_count)+outc1.it;
        inneritcount(Method_count)=inneritcount(Method_count)+outc1.innerit;
        rescount(Method_count)=rescount(Method_count)+outc1.F(end);
        %% IOSA-adaptive-beta;
        Method_count=Method_count+1;
        beta=1; tau=0.5; alpha=0.1; opt.gamma=1.85; opt.tol=tol;
        opt.n=n; opt.maxit=5000; opt.x=xini; opt.beta=beta;
        opt.betastyle='Adaptive'; opt.alpha=alpha; opt.tau=tau;
        outA=IOSA(A,bvector,opt);
        timecount(Method_count)=timecount(Method_count)+outA.time;
        itcount(Method_count)=itcount(Method_count)+outA.it;
        inneritcount(Method_count)=inneritcount(Method_count)+outA.innerit;
        rescount(Method_count)=rescount(Method_count)+outA.F(end);                
    end  
end

%% 输出
disp('-------------------------------------------------------------------')
disp('------------------—--------   输出结果   ---------------------------')
disp('-------------------------------------------------------------------')
disp('    fav        outIter.      innerIter.      Res ')
for i=1:N
    fprintf(' %3d    %4d         %4d      %6.2e \n',timecount(i),itcount(i),inneritcount(i),rescount(i));
end
disp('-------------------------------------------------------------------')
end
end


%% plot Fig2_a
plot(1:out.it,log(out.F),'b-x','LineWidth',1.5);
hold on
plot(1:outc.it,log(outc.F),'k:+','LineWidth',1.5)
hold on
plot(1:outA.it,log(outA.F),'r-->','LineWidth',1.5)
hold on
plot(1:outc1.it,log(outc1.F),'c:*','LineWidth',1.5)
hold on 
plot(1:outA1.it,log(outA1.F),'m:s','LineWidth',1.5)
grid on
legend('Method in [16]','Algorithm 3.1-C','Algorithm 3.1-A','Algorithm 4.1-C','Algorithm 4.1-A')
xlabel('Iteration', 'fontsize', 14); ylabel('log(||e(x^k,1)||)', 'fontsize', 14);
















