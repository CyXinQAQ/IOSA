
clc,clear

np=1;
sp=0;

n=1000;
vcond = 1000 + (1200 - 1000).*rand(np,1);

vdensity = 0.95 + (0.92 - 0.9).*rand(np,1);

%vdensity = 0.8 + (0.82 - 0.8).*rand(np,1);

gamma = 1.85;
tol   = 1e-6;

cs = 1; % solve each problem five times

VcondA = zeros(np,1);
Vdensity = zeros(np,1);

N=5;%算法的个数
timecount=zeros(1,N);
itcount=zeros(1,N);
inneritcount=zeros(1,N);
rescount=zeros(1,N);

for i = 1:np
    
     fprintf('The number of test problems is: %d \n',i)
    
    [A,bvector,~,xini,theta,~,normAinv,~,condA,density] = data( n, vdensity(i), vcond(i) );
    VcondA(i) = condA;
    Vdensity(i) = density;
    
    
    for j = 1:cs % run each method cs times

        
        tau=0.5;
        opt.beta=1;
        opt.gamma=1.85;
        opt.tol=tol;
        opt.n=n;
        opt.maxit=5000;
        opt.x=xini;
        
        opt.betastyle='Adaptive';
        opt.tau=tau;
        
        opt.alpha=0.1;
        outc0=IOSA1(A,bvector,opt)
        opt.alpha=0.5;
        outc1=IOSA1(A,bvector,opt)
        opt.alpha=1;
        outc2=IOSA1(A,bvector,opt)
                opt.alpha=1.5;
        outc3=IOSA1(A,bvector,opt)
                opt.alpha=2;
        outc4=IOSA1(A,bvector,opt)
                opt.alpha=2.5;
        outc5=IOSA1(A,bvector,opt)
        
        
    end
    
    
end




outc0.Trecord(1)=0;
outc1.Trecord(1)=0;
outc2.Trecord(1)=0;
outc3.Trecord(1)=0;
outc4.Trecord(1)=0;
outc5.Trecord(1)=0;
plot(outc0.Trecord,log(outc0.F),'b-','LineWidth',1.5);
hold on
plot(outc1.Trecord,log(outc1.F),'r--','LineWidth',1.5);
hold on
plot(outc2.Trecord,log(outc2.F),'g:','LineWidth',1.5);
hold on
plot(outc3.Trecord,log(outc3.F),'m-','LineWidth',1.5);
hold on
plot(outc4.Trecord,log(outc4.F),'b:','LineWidth',1.5);
hold on
plot(outc5.Trecord,log(outc5.F),'k--','LineWidth',1.5);

grid on

% ylim([-1 100])
% xlim([0 50])
%legend('IMA-IDR','非精确1','非精确2','IOSA')
legend('\alpha=0.1','\alpha=0.5','\alpha=1','\alpha=1.5','\alpha=2','\alpha=2.5')
xlabel('Time (seconds)', 'fontsize', 14); ylabel('log(||e(x^k,1)||)', 'fontsize', 14);








