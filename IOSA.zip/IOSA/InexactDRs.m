function out = InexactDRs( A, b, x, n, gamma, tol)

% This is Inexact Douglas-Rachford splitting method for Absolute Value Equations
% (AVE): Ax - |x| = b

% Reference: C.-R. Chen, D.-M. Yu, D.-R. Han. An inexact Douglas-Rachford splitting
%            method for solving absolute value equations

%--------------------- Input arguments ------------------------------------

% n: dimension of the problem

% gamma: iteration parameter

% A, b: data of the problem Ax - |x| = b;
%       A is nxn real matrix and b is nx1 real vector

% x: initial point; nx1 real vector

% tol: accuracy for solution of AVE
%      The method stops at x if || Ax - |x| - b || <= tol


%--------------------- Output arguments -----------------------------------

% x: final iterate

% F: norm of AVE at the final iterate x;
%    F = || Ax - |x| - b ||

% it: number of iterations of inExact Douglas-Rachford splitting method

% time: Total CPU time in seconds

% flag = -1: an error occurred during the execution
% flag =  0: solution was found
% flag =  1: maximum of iterations reached

%-----------------------  Dependence --------------------------------------

% function: olsqr

% Print initial information

%disp('-------------------------------------------------------------------')
%disp('------------------   Initial Information   ------------------------')
%disp('-------------------------------------------------------------------')
%disp('-------------------------------------------------------------------')
%disp('-------------  Inexact Douglas-Rachford splitting method ----------')
%disp('-------------------------------------------------------------------')
% disp(' ')
% disp(' It   || Ax - |x| - b ||      LSQRtol    LSQRit   flagLSQR')
% disp(' ')

t=tic;
flag = -1;
gamma = 0.5*gamma;
maxit = 50000;
it = 1;

kmax = 10;


[atype,afun,afcnstr] = iterchk(A);

inner=0;
while it <= maxit
    Ax = iterapp('mtimes',afun,atype,afcnstr,x);
    %Ax=A*x;
    res = Ax - abs(x) -b;
    out.F(it) = norm( res );
    out.Trecord(it)=toc(t);
                out.x=x;
        out.inner=inner;
            out.it=it;
    if out.F(it) <= tol
        break;
    end

    
    alpha = min([ 0.9, 1/( max([ 1, it-kmax ]) ) ]);
    %alpha=1e-4;
    rh = Ax - gamma*res; % gamma = 0.5*gamma
    LStol = alpha*out.F(it);
    
    [x, flagLS, iter ] = olsqr(A,rh,LStol,n,x);
 
    inner=inner+iter;
    
    %  fprintf(' %3d       %6.2e         %6.2e    %4d      %d \n',it, out.F(it), LStol, iter, flagLS);
    
    
    
    it = it + 1;
    
end

if it == ( maxit + 1 )
    
    out.flag = 1;
    out.time = toc(t);
    %disp('Inexact Douglas-Rachford splitting method fails to find the solution')
    %disp('Maximum of iterations reached ')
    %fprintf('Time = %10.4f \n',out.time)
    
else
    
    out.flag = 0;
    out.time = toc(t);
    disp(' ')
    %disp('Solution is found')
    %fprintf('Time = %10.4f \n',out.time)
    
end
out.x=x;
end

