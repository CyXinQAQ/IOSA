%generate imax instances of solvable AVE Ax-|x|=b & solve by SLA:
%min e’(Ax-b)-e’|x| s.t. -Ax+b =< x =< Ax-b
%input: n,imax,itmax (itmax=maximum no. of iterations typically 40)
%output: total number of violated equations for all instnances (nnztot),
%max no. of violated equations per instance (nnzx), total LPs & time (toc)
%lpxt(c,B,d) is CPLEX call to solve min c’x s.t. Bx =< d
function out=SLA(A,b,n,option)
imax=option.imax;
itmax=option.itmax;
I=eye(n);e=ones(n,1);
nnztot=0;nnzx=0;k=0;t0=tic; %k is total number of LPs for all imax instances
for i=1:imax
%A=10*(rand(n,n)-rand(n,n));x=rand(n,1)-rand(n,1);b=A*x-abs(x);%generate AVE
j=1;y=rand(n,1)-rand(n,1);%generate initial point y
while(j<itmax && norm(A*y-abs(y)-b)>1e-6)%{\ul itmax} or AVE error stop
c=[A'*e-sign(y)];B=[-(A+I) ;(-A+I) ];d=[-b;-b];[z]=linprog(c,B,d);
y=z; j=j+1;
end
err=(A*y-abs(y)-b);nnz1=nnz(find(abs(err)>1e-6));
nnztot=nnztot+nnz1;nnzx=max([nnz1 nnzx]);k=k+j-1;
end
out.it=k;
out.time=toc(t0);
[nnztot nnzx k]