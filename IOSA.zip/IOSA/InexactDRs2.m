function [F,x,it,time,flag] = InexactDRs1( A, b, x, n, gamma, tol)

% This is Inexact Douglas-Rachford splitting method for Absolute Value Equations 
% (AVE): Ax - |x| = b

% Reference: C.-R. Chen, D.-M. Yu, D.-R. Han. An inexact Douglas-Rachford splitting 
%            method for solving absolute value equations

%--------------------- Input arguments ------------------------------------

% n: dimension of the problem

% gamma: iteration parameter

% A, b: data of the problem Ax - |x| = b; 
%       A is nxn real matrix and b is nx1 real vector 

% x: initial point; nx1 real vector 

% tol: accuracy for solution of AVE
%      The method stops at x if || Ax - |x| - b || <= tol


%--------------------- Output arguments -----------------------------------

% x: final iterate

% F: norm of AVE at the final iterate x; 
%    F = || Ax - |x| - b ||

% it: number of iterations of inExact Douglas-Rachford splitting method 

% time: Total CPU time in seconds

% flag = -1: an error occurred during the execution
% flag =  0: solution was found
% flag =  1: maximum of iterations reached

%-----------------------  Dependence --------------------------------------

% function: olsqr

% Print initial information

g=@(x) A*x+x-b;
f=@(x) A*x-x-b;

disp('-------------------------------------------------------------------')
disp('------------------   Initial Information   ------------------------')
disp('-------------------------------------------------------------------')
disp('-------------------------------------------------------------------')
disp('-------------  Inexact Douglas-Rachford splitting method-2 ----------')
disp('-------------------------------------------------------------------')
disp(' ')
disp(' It   || Ax - |x| - b ||      LSQRtol    LSQRit   flagLSQR')
disp(' ')

tic;
flag = -1;

maxit = 500;
it = 1;


[atype,afun,afcnstr] = iterchk(A);
x_old=x;
beta=1.5;
alpha=1;
LStol=0;
ATA=A'*A;
while it <= maxit
    Ax = iterapp('mtimes',afun,atype,afcnstr,x_old);
    
    res = Ax - abs(x_old) -b;
    F(it) = norm( res );
    
    
    C=(1+beta)*A+(1-beta)*eye(n);
    gold=g(x_old);
    fold=f(x_old);
    rh=C*x_old-gamma*(gold-max((gold-beta*fold),0));
    if it<=10
        eta=1;
    else
        eta=1/it;
    end
    eta=0.15;
    option.beta=beta;
    option.eta=eta;
    [x_new, flagLS, iter ] = olsqr2(C,rh,LStol,n,x_old,A,b,option);
    
    %fprintf(' %3d       %6.2e         %6.2e    %4d      %d \n',it, F(it), LStol, iter, flagLS)
    
        x_res=x_old-x_new;
    LStol=0.99*beta*x_res'*(ATA-eye(n))*x_res;
    
    W=beta*norm(f(x_new)-fold)/norm(g(x_new)-gold);
    if W<1/(1+alpha)
        beta=(1+0.5)*beta;
    elseif W>1+alpha
        beta=beta/(1+0.5);
    else
        beta=beta;
    end
    x_old=x_new;
    if F(it) <= tol
        break
    end

    it = it + 1;

end

if it == ( maxit + 1 )
    
    flag = 1;
    time = toc;
    disp('Inexact Douglas-Rachford splitting method fails to find the solution')
    disp('Maximum of iterations reached ')
    fprintf('Time = %10.4f \n',time)
    
else
    
    flag = 0;
    time = toc;
    disp(' ')
    disp('Solution is found')
    fprintf('Time = %10.4f \n',time)
    
end

end

