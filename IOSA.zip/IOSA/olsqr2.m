function [x, flag, k ,error] = olsqr2(A,b,n,x_old,B,c,option,varargin)
maxit = 2*n;
eta=option.eta;
beta=option.beta;
BTB=B'*B;
g=@(y) B*y+y-c;
f=@(y) B*y-y-c;


[atype,afun,afcnstr] = iterchk(A);

u = b - iterapp('mtimes',afun,atype,afcnstr,x_old,varargin{:});  % r = b - A*x
beta = norm(u);
u = u/beta;

v = iterapp('mtimes',afun,atype,afcnstr,u,varargin{:},'transp');
alpha = norm(v);
v = v/alpha;

w = v;

phibar = beta;
rhohat = alpha;

k = 1;
flag = -1; % an error occurred during the execution
while k<= maxit
    
    u = iterapp('mtimes',afun,atype,afcnstr,v,varargin{:}) - alpha*u;
    beta = norm(u);
    u = u/beta;
    
    v = iterapp('mtimes',afun,atype,afcnstr,u,varargin{:},'transp') - beta*v;
    alpha = norm(v);
    v = v/alpha;
    
    rho = sqrt( rhohat^2 + beta^2 );
    c = rhohat/rho;
    s = beta/rho;
    theta = s*alpha;
    rhohat = -c*alpha;
    phi = c*phibar;
    phibar = s*phibar;
    
    
    x_new= x_old + (phi*w)/rho;
    w = v - (theta*w)/rho;
    
    x_res=x_old-x_new;
    tol=0.2*2*x_res'*(BTB-eye(n))*x_res;

    %tol=0.01*norm(A*x_old-abs(x_old)-b)^2;
    %tol=1*norm(g(x_old)-max(g(x_old)-beta*f(x_old),0)-g(x_new)+max(g(x_new)-beta*f(x_new),0));
    
       
    if phibar^2 <= tol % || b - Ax_k || <= tol
        flag = 0; % success
        error=tol;
        x=x_new;
        break
    end
    k = k + 1;
end

end
