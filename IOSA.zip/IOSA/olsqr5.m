function [x, flag, k ] = olsqr5(A,b,tol,n,x,varargin)
maxit = 2*n;

[atype,afun,afcnstr] = iterchk(A);

u = b - iterapp('mtimes',afun,atype,afcnstr,x,varargin{:});  % r = b - A*x
beta = norm(u);
u = u/beta;

v = iterapp('mtimes',afun,atype,afcnstr,u,varargin{:},'transp');
alpha = norm(v);
v = v/alpha;

w = v;

phibar = beta;
rhohat = alpha;

k = 1;
flag = -1; % an error occurred during the execution
while k<= maxit
    

    
    u = iterapp('mtimes',afun,atype,afcnstr,v,varargin{:}) - alpha*u;
    beta = norm(u);
    u = u/beta;
    
    v = iterapp('mtimes',afun,atype,afcnstr,u,varargin{:},'transp') - beta*v;
    alpha = norm(v);
    v = v/alpha;
    
    rho = sqrt( rhohat^2 + beta^2 );
    c = rhohat/rho;
    s = beta/rho;
    theta = s*alpha;
    rhohat = -c*alpha;
    phi = c*phibar;
    phibar = s*phibar;
    
    
    x = x + (phi*w)/rho;
    w = v - (theta*w)/rho;
    
        if phibar^2 <= tol % || b - Ax_k || <= tol
        flag = 0; % success
        break
    end
    
    k = k + 1;
end

end
