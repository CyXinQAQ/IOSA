%���ݷ�����-mvpower.m
function [lam]=mvpower(dA,n)
x0 = ones(n,1);
tolp = 1e-8;
N = 1500;

% R = deconposition(A,'chol');

k = 1;   
while (k < N)
   v = x0./norm(x0,2);
   x0 = dA\v;
   theta = v'*x0;
   
   if norm(x0 - theta*v,2) <= tolp*abs(theta)
       break
   end
   
   k = k + 1; 
   
end
lam = theta; % alpha = 0, the smallest eigenvalue of A  % the 2-norm of A
