function [F, x, it, time, flag] = Newton(A, b, n, sp, x, tol)

% This is Exact semi-smooth Newton method for Absolute Value Equations 
% (AVE): Ax - |x| = b

% Reference: J.Y. Bello Cruz, O. P. Ferreira, L. F. Prudente. On the global
%            convergence of the inexact semi-smooth Newton method for 
%            absolute value equation

%--------------------- Input arguments ------------------------------------

% n: dimension of the problem

% A, b: data of the problem Ax - |x| = b; 
%       A is nxn real matrix and b is nx1 real vector 

% x: initial point; nx1 real vector 

% sp: sparsity indicator
%     if sp  = 0: full storage organization is used
%     if sp ~= 0: sparse storage organization is used

% tol: accuracy for solution of AVE
%      The method stops at x if ||Ax - |x| - b|| <= tol


%--------------------- Output arguments -----------------------------------

% x: final iterate

% F: norm of AVE at the final iterate x; 
%    F = || Ax - |x| - b ||

% it: number of iterations of Exact Newton method

% time: Total CPU time in seconds

% flag = -1: an error occurred during the execution
% flag =  0: solution was found
% flag =  1: maximum of iterations reached

% Print initial information

disp('-------------------------------------------------------------------')
disp('------------------   Initial Information   ------------------------')
disp('-------------------------------------------------------------------')
disp('-------------------------------------------------------------------')
disp('--------------  Exact semi-smooth Newton method  ------------------')
disp('-------------------------------------------------------------------')
disp(' ')
disp(' It   || Ax - |x| - b ||')
disp(' ')

tic;

flag = -1; % an error occurred during the execution

[atype,afun,afcnstr] = iterchk(A);
maxit = 50;
it = 0;

while it <= maxit
    
    Ax = iterapp('mtimes',afun,atype,afcnstr,x);
    F = norm( Ax - abs(x) -b );
    
    
    % Print information
    fprintf(' %3d       %6.2e \n',it, F)
    
    if ( sp == 0 )
        AD = A - diag(sign(x));
    else    
        AD = A - sparse(1:n,1:n,sign(x),n,n);
    end
    
    dA = decomposition(AD,'lu');
        
    x = dA\b;
    
    if F <= tol
        break
    end
    
    
    it = it + 1;
    
end

if it == ( maxit + 1 )
    
    flag = 1;
    time = toc;
    disp('Exact semi-smooth Newton method fails to find the solution')
    disp('Maximum of iterations reached ')
    fprintf('Time = %10.4f \n',time)
    
else
    
    flag = 0;
    time = toc;
    disp(' ')
    disp('Solution is found')
    fprintf('Time = %10.4f \n',time)
    
end

end

