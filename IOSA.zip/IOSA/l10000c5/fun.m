function df = fun(w,v)
r = 3*(w-1)^2 + 2*v^2*w^4 + 2*v*w^2*(1-w);
s = 6*(w-1) + 8*v^2*w^3 + 2*v*(-3*w^2 + 2*w);

df = s + ( r*s - 8*(w-1)^3 )/sqrt( r^2 - 4*(w-1)^4 );
end