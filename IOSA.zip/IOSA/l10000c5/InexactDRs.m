function [F,x,it,time,flag] = InexactDRs( A, b, x, n, gamma, tol)

% This is Inexact Douglas-Rachford splitting method for Absolute Value Equations 
% (AVE): Ax - |x| = b

% Reference: C.-R. Chen, D.-M. Yu, D.-R. Han. An inexact Douglas-Rachford splitting 
%            method for solving absolute value equations

%--------------------- Input arguments ------------------------------------

% n: dimension of the problem

% gamma: iteration parameter

% A, b: data of the problem Ax - |x| = b; 
%       A is nxn real matrix and b is nx1 real vector 

% x: initial point; nx1 real vector 

% tol: accuracy for solution of AVE
%      The method stops at x if || Ax - |x| - b || <= tol


%--------------------- Output arguments -----------------------------------

% x: final iterate

% F: norm of AVE at the final iterate x; 
%    F = || Ax - |x| - b ||

% it: number of iterations of Exact Douglas-Rachford splitting method 

% time: Total CPU time in seconds

% flag = -1: an error occurred during the execution
% flag =  0: solution was found
% flag =  1: maximum of iterations reached

%-----------------------  Dependence --------------------------------------

% function: olsqr

% Print initial information

disp('-------------------------------------------------------------------')
disp('------------------   Initial Information   ------------------------')
disp('-------------------------------------------------------------------')
disp('-------------------------------------------------------------------')
disp('-------------  Inexact Douglas-Rachford splitting method ----------')
disp('-------------------------------------------------------------------')
disp(' ')
disp(' It   || Ax - |x| - b ||      LSQRtol    LSQRit   flagLSQR')
disp(' ')

tic;
flag = -1;
gamma = 0.5*gamma;
maxit = 50;
it = 0;

kmax = 10;
        

[atype,afun,afcnstr] = iterchk(A);


while it <= maxit
    Ax = iterapp('mtimes',afun,atype,afcnstr,x);
    res = Ax - abs(x) -b;
    F = norm( res );
    
    alpha = min([ 0.9, 1/( max([ 1, it-kmax ]) ) ]);
    

    rh = Ax - gamma*res; % gamma = 0.5*gamma
    LStol = alpha*F;
    
    [x, flagLS, iter ] = olsqr(A,rh,LStol,n,x);
    
    fprintf(' %3d       %6.2e         %6.2e    %4d      %d \n',it, F, LStol, iter, flagLS)
    
    if F <= tol
        break
    end

    it = it + 1;

end

if it == ( maxit + 1 )
    
    flag = 1;
    time = toc;
    disp('Inexact Douglas-Rachford splitting method fails to find the solution')
    disp('Maximum of iterations reached ')
    fprintf('Time = %10.4f \n',time)
    
else
    
    flag = 0;
    time = toc;
    disp(' ')
    disp('Solution is found')
    fprintf('Time = %10.4f \n',time)
    
end

end

