function [ rm ] = Test3( n, np, sp)

% sp: sparsity indicator
%     if sp  = 0: full storage organization is used
%     if sp ~= 0: sparse storage organization is used

% n = 10000
% vcond = 100000 + (100010 - 100000).*rand(np,1);
% vdensity = 0.003 + (0.004 - 0.003).*rand(np,1);


% n = 100
vcond = 100 + (120 - 100).*rand(np,1);
vdensity = 0.003 + (0.004 - 0.003).*rand(np,1);
% 
cd=10000;
vcond = cd + (cd*0.2).*rand(np,1);
vdensity = 0.95 + (0.92 - 0.9).*rand(np,1);

% n = 10000
%vcond = 10 + (30 - 10).*rand(np,1);
%vdensity = 0.003 + (0.004  - 0.003).*rand(np,1);


gamma = 1.85;
tol   = 1e-6;

cs = 5; % solve each problem five times
VcondA = zeros(np,1);
Vdensity = zeros(np,1);
vmintime = zeros(np,1);
vrm = zeros(np,1); 
vtimen = zeros(np,1);
vtimein = zeros(np,1);
vtimed = zeros(np,1);
vtimeid = zeros(np,1);
vtimes = zeros(np,1);
vflagn = zeros(np,1);
vflagin = zeros(np,1);
vflagd = zeros(np,1);
vflagid = zeros(np,1);
vflags = zeros(np,1);

for i = 1:np
    
    fprintf('The number of test problems is: %d \n',i)
    
    [A,bvector,~,xini,theta,~,normAinv,~,condA,density] = data( n, vdensity(i), vcond(i) );

    VcondA(i) = condA; 
    Vdensity(i) = density;
    
    
    timen = zeros(cs,1);
    timein = zeros(cs,1);
    timed = zeros(cs,1);
    timeid = zeros(cs,1);
    times = zeros(cs,1);
    timeIOSA=zeros(cs,1);
    
    for j = 1:cs % run each method cs times
        
        [~,~,~,timenew,flagn] = Newton(A,bvector,n,sp,xini,tol);
        timen(j) = timenew;
        
        [~,~,~,timeienew,flagin] = InexactNewton(A,bvector,n,sp,xini,theta,tol);
        timein(j) = timeienew;
        
        [ ~, ~, ~, timeedrs, flagd]  = DRs( A, bvector, xini, gamma, tol);
        timed(j) = timeedrs;
       
        [~,~,~,timeiedrs,flagid] = InexactDRs( A, bvector, xini, n, gamma, tol);
        timeid(j) = timeiedrs;
        
        [~,~, ~, timeesor, flags ] = SORl( A, bvector, xini, xini, normAinv, tol);
        times(j) = timeesor;
        
        beta=1; tau=0.5; alpha=0.1; opt.gamma=1.85; opt.tol=tol; opt.n=n;
        opt.maxit=50; opt.x=xini; opt.beta=beta; opt.betastyle='Adaptive';
        opt.alpha=alpha; opt.tau=tau;
        outA1=IOSA1(A,bvector,opt);
        timeIOSA(j)=outA1.time;
        
        
    end
    
    %%%%%%%%% average of running time %%%%%%%%%%%%%%%
    timen = mean(timen(:));
    timein = mean(timein(:));
    timed = mean(timed(:));
    timeid = mean(timeid(:));
    times = mean(times(:));
    timeIOSA= mean(timeIOSA(:));
    
    mintime = min([timen,timein,timed,timeid,times,timeIOSA]);
    maxtime = max([timen,timein,timed,timeid,times,timeIOSA]);
    vmintime(i) = mintime;
    vrm(i) = maxtime/mintime;
    
    vtimen(i) = timen;
    vtimein(i) = timein;
    vtimed(i) = timed;
    vtimeid(i) = timeid;
    vtimes(i) = times;
    vtimeIOSA(i)=timeIOSA;
    
    vflagn(i) = flagn;
    vflagin(i) = flagin;
    vflagd(i) = flagd;
    vflagid(i) = flagid;
    vflags(i) = flags;
    vflagIOSA(i)=outA1.flag;
    
end

rmo = max(vrm);
rm = ceil(rmo) + 10;

rpsn = zeros(np,1);
rpsin = zeros(np,1);
rpsd = zeros(np,1);
rpsid = zeros(np,1);
rpss = zeros(np,1);
rpIOSA=zeros(np,1);

for i = 1:np
    if vflagn(i) == 0
        rpsn(i) = vtimen(i)/vmintime(i);
    else
        rpsn(i) = rm;
    end
    
    if vflagin(i) == 0
        rpsin(i) = vtimein(i)/vmintime(i);
    else
        rpsin(i) = rm;
    end

    if vflagd(i) == 0
        rpsd(i) = vtimed(i)/vmintime(i);
    else
        rpsd(i) = rm;
    end
    
    if vflagid(i) == 0
        rpsid(i) = vtimeid(i)/vmintime(i);
    else
        rpsid(i) = rm;
    end
    
    if vflags(i) == 0
        rpss(i) = vtimes(i)/vmintime(i);
    else
        rpss(i) = rm;
    end
    if vflagIOSA(i)==0
    rpIOSA(i)=vtimeIOSA(i)/vmintime(i);
    else
        rpIOSA(i)=rm;
    end
end

tau = 1:0.01:rm;
lt = length(tau);
rhon = zeros(lt,1);
rhoin = zeros(lt,1);
rhod = zeros(lt,1);
rhoid = zeros(lt,1);
rhos = zeros(lt,1);
rhoIOSA = zeros(lt,1);
for l = 1:lt
    rhon(l) = sum(rpsn <= tau(l))/np;
    rhoin(l) = sum(rpsin <= tau(l))/np;
    rhod(l) = sum(rpsd <= tau(l))/np;
    rhoid(l) = sum(rpsid <= tau(l))/np;
    rhos(l) = sum(rpss <= tau(l))/np; 
    rhoIOSA(l) = sum(rpIOSA <= tau(l))/np; 
    
end



%%%%%%%%% plots
close all

figure(1)

plot(tau,rhon,'b-.','LineWidth',1.5)
hold on
plot(tau,rhoin,'b-.','LineWidth',3)
plot(tau,rhod,'r--','LineWidth',1.5)
plot(tau,rhoid,'r--','LineWidth',3)
plot(tau,rhos,'m:','LineWidth',1.5)
plot(tau,rhoIOSA,'m:','LineWidth',3)
hold off
axis([0 rm 0 1])
legend('Newton','InexactNewton','DRs','InexactDRs','SOR-like','IOSA')
xlabel('$$\tau$$','Interpreter','latex','FontSize',18)
ylabel('$$P(r_{p,s} \le \tau: 1\le s\le n_s$$)','Interpreter','latex','FontSize',18)




    
        