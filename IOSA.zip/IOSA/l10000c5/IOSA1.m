function out=IOSA1(A,b,opt)
gamma=opt.gamma;
tol=opt.tol;
n=opt.n;
maxit=opt.maxit;
x_0=opt.x;
betastyle=opt.betastyle;

%g=@(x) A*x+x-b;
f=@(x) A*x-x-b;
ATA=A'*A;
B=ATA-eye(n);
R=@(x) x'*B*x;


x_old=x_0;
%ATA=A'*A;
it=1;
innerit=0;
beta=opt.beta;
alpha=opt.alpha;
%kmax=10;

innertol=1e-1;
[atype,afun,afcnstr] = iterchk(A);
t0=tic;


%      x_res=x_old-x_new;
% innertol=option.eta*beta*R(x_res)
% fprintf(' %3d       %6.2e         %6.2e    %4d      %d \n',it, F(it), innertol, iter, flagLS);


%% beta 的选取方式
switch betastyle
    case 'constant'
        while it <= maxit
            if it<=10
                option.eta=0.01;
            else
                option.eta=1/it;
            end
            beta=opt.beta;
            Ax = iterapp('mtimes',afun,atype,afcnstr,x_old);
            res = Ax - abs(x_old) -b;
            F(it) = norm( res );
            
            C=(1+beta)*A+(1-beta)*eye(n);
            temp=Ax-b;
            gold=temp+x_old;
            fold=temp-x_old;
            rh=(1+beta)*Ax+(1-beta)*x_old-gamma*(gold-max((gold-beta*fold),0)); 
            
            option.beta=beta;
            option.res=res;
            option.tol=innertol;
            
            [x_new, flagLS, iter,error] = olsqr4(C,rh,n,x_old,B,b,option,[]);
            innerit=innerit+iter;
            x_res=x_old-x_new;
            innertol=sqrt(option.eta*beta*R(x_res));
          
            x_old=x_new;
            out.Trecord(it)=toc(t0);
            out.F(it)=F(it);
            out.innerit=innerit;
            out.it=it;
            if F(it) <= tol
                break
            end
             
            it = it + 1;
        end
    case 'Adaptive'
        while it <= maxit
            Ax = iterapp('mtimes',afun,atype,afcnstr,x_old);
            res = Ax - abs(x_old) -b;
            F(it) = norm( res );
            
            C=(1+beta)*A+(1-beta)*eye(n);
            temp=Ax-b;
            gold=temp+x_old;
            fold=temp-x_old;
            rh=(1+beta)*Ax+(1-beta)*x_old-gamma*(gold-max((gold-beta*fold),0));
            
            if it<=10
                option.eta=0.01;
            else
                option.eta=1/it;
            end
            option.beta=beta;
            option.res=res;
            option.tol=innertol;
            
            [x_new, flagLS, iter,error] = olsqr4(C,rh,n,x_old,B,b,option,[]);
            %[x_new, flagLS, iter ] = olsqr(C,rh,eta,n,x_old);
            %     alpha = min([ 0.2, 1/( max([ 1, it-kmax ]) ) ]);
            %     rh = A*x_old - 0.5* gamma*res; % gamma = 0.5*gamma
            %     LStol = alpha*F(it);
            %     [x_new, flagLS, iter ] = olsqr(A,rh,LStol,n,x_old);
            innerit=innerit+iter;
            out.Trecord(it)=toc(t0);
            
            x_res=x_old-x_new;
            innertol=sqrt(option.eta*beta*R(x_res));
            tau=opt.tau;
            fnew=f(x_new);
            W=beta*norm(fnew-fold)/norm(fnew+2*x_new-gold);
            if W<(1/(1+alpha))
                beta=(1+tau)*beta;
            elseif W>(1+alpha)
                beta=beta/(1+tau);
            end
            
             x_old=x_new;
            

            out.F=F;
            out.it=it;
            out.innerit=innerit;
            if F(it) <= tol
                break
            end
            
            it = it + 1;
        end
end
out.time=toc(t0);
if it == ( maxit + 1 )   
    out.flag = 1;   
else   
    out.flag = 0;  
end




end
